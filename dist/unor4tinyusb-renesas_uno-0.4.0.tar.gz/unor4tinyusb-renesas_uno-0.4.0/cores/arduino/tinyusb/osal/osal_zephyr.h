/*
 * SPDX-FileCopyrightText: Copyright (c) 2025 Ha Thach (tinyusb.org)
 * SPDX-License-Identifier: MIT
 *
 * This file is part of the TinyUSB stack.
 */
#ifndef TUSB_OSAL_ZEPHYR_H
#define TUSB_OSAL_ZEPHYR_H

#include <zephyr/kernel.h>

//--------------------------------------------------------------------+
// TASK API
//--------------------------------------------------------------------+
typedef k_tid_t osal_task_handle_t;

TU_ATTR_ALWAYS_INLINE static inline osal_task_handle_t osal_task_get_current_handle(void) {
  return k_current_get();
}

TU_ATTR_ALWAYS_INLINE static inline void osal_task_delay(uint32_t msec) {
  k_msleep(msec);
}

TU_ATTR_ALWAYS_INLINE static inline uint32_t osal_time_millis(void) {
  return k_uptime_get_32();
}

//--------------------------------------------------------------------+
// Spinlock API
//--------------------------------------------------------------------+
typedef struct {
  struct k_spinlock lock;
  k_spinlock_key_t key;
} osal_spinlock_t;

#define OSAL_SPINLOCK_DEF(_name, _int_set) \
  osal_spinlock_t _name

TU_ATTR_ALWAYS_INLINE static inline void osal_spin_init(osal_spinlock_t *ctx) {
  (void) ctx;
}

TU_ATTR_ALWAYS_INLINE static inline void osal_spin_deinit(osal_spinlock_t *ctx) {
  (void) ctx;
}

TU_ATTR_ALWAYS_INLINE static inline void osal_spin_lock(osal_spinlock_t *ctx, bool in_isr) {
  if (!TUP_MCU_MULTIPLE_CORE && in_isr) {
    return; // single core MCU does not need to lock in ISR
  }
  ctx->key = k_spin_lock(&ctx->lock);
}

TU_ATTR_ALWAYS_INLINE static inline void osal_spin_unlock(osal_spinlock_t *ctx, bool in_isr) {
  if (!TUP_MCU_MULTIPLE_CORE && in_isr) {
    return; // single core MCU does not need to lock in ISR
  }
  k_spin_unlock(&ctx->lock, ctx->key);
}

//--------------------------------------------------------------------+
// Binary Semaphore API
//--------------------------------------------------------------------+
typedef struct k_sem osal_semaphore_def_t, * osal_semaphore_t;

TU_ATTR_ALWAYS_INLINE static inline osal_semaphore_t osal_semaphore_create(osal_semaphore_def_t* semdef) {
  k_sem_init(semdef, 0, 255);
  return semdef;
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_semaphore_delete(osal_semaphore_t semd_hdl) {
  (void) semd_hdl;
  return true; // nothing to do
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_semaphore_post(osal_semaphore_t sem_hdl, bool in_isr) {
  (void) in_isr;
  k_sem_give(sem_hdl);
  return true;
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_semaphore_wait(osal_semaphore_t sem_hdl, uint32_t msec) {
  return 0 == k_sem_take(sem_hdl, K_MSEC(msec));
}

TU_ATTR_ALWAYS_INLINE static inline void osal_semaphore_reset(osal_semaphore_t sem_hdl) {
  k_sem_reset(sem_hdl);
}

//--------------------------------------------------------------------+
// MUTEX API
//--------------------------------------------------------------------+
typedef struct k_mutex osal_mutex_def_t, *osal_mutex_t;

TU_ATTR_ALWAYS_INLINE static inline osal_mutex_t osal_mutex_create(osal_mutex_def_t* mdef) {
  if ( 0 == k_mutex_init(mdef) ) {
    return mdef;
  } else {
    return NULL;
  }
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_mutex_delete(osal_mutex_t mutex_hdl) {
  (void) mutex_hdl;
  return true; // nothing to do
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_mutex_lock(osal_mutex_t mutex_hdl, uint32_t msec) {
  return 0 == k_mutex_lock(mutex_hdl, K_MSEC(msec));
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_mutex_unlock(osal_mutex_t mutex_hdl) {
  return 0 == k_mutex_unlock(mutex_hdl);
}

//--------------------------------------------------------------------+
// QUEUE API
//--------------------------------------------------------------------+
typedef struct k_msgq osal_queue_def_t, * osal_queue_t;

// role device/host is used by OS NONE for mutex (disable usb isr) only
#define OSAL_QUEUE_DEF(_int_set, _name, _depth, _type)  K_MSGQ_DEFINE(_name, sizeof(_type), _depth, 4)

TU_ATTR_ALWAYS_INLINE static inline osal_queue_t osal_queue_create(osal_queue_def_t* qdef) {
  // K_MSGQ_DEFINE already initializes the queue
  return (osal_queue_t) qdef;
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_queue_delete(osal_queue_t qhdl) {
  (void) qhdl;
  return true;
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_queue_receive(osal_queue_t qhdl, void* data, uint32_t msec) {
  return 0 == k_msgq_get(qhdl, data, K_MSEC(msec));
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_queue_send(osal_queue_t qhdl, void const* data, bool in_isr) {
  return 0 == k_msgq_put(qhdl, data,  in_isr ? K_NO_WAIT : K_FOREVER);
}

TU_ATTR_ALWAYS_INLINE static inline bool osal_queue_empty(osal_queue_t qhdl) {
  return 0 == k_msgq_num_used_get(qhdl);
}

#endif
