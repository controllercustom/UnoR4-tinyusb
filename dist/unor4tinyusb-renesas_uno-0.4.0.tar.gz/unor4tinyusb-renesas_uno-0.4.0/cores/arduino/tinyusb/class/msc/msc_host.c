/*
 * SPDX-FileCopyrightText: Copyright (c) 2019 Ha Thach (tinyusb.org)
 * SPDX-License-Identifier: MIT
 *
 * This file is part of the TinyUSB stack.
 */

#include "tusb_option.h"

#if CFG_TUH_ENABLED && CFG_TUH_MSC

#include "host/usbh.h"
#include "host/usbh_pvt.h"

#include "msc_host.h"

// Level where CFG_TUSB_DEBUG must be at least for this driver is logged
#ifndef CFG_TUH_MSC_LOG_LEVEL
  #define CFG_TUH_MSC_LOG_LEVEL   CFG_TUH_LOG_LEVEL
#endif

#define TU_LOG_DRV(...)   TU_LOG(CFG_TUH_MSC_LOG_LEVEL, __VA_ARGS__)

//--------------------------------------------------------------------+
// MACRO CONSTANT TYPEDEF
//--------------------------------------------------------------------+
enum {
  MSC_STAGE_IDLE = 0,
  MSC_STAGE_CMD,
  MSC_STAGE_DATA,
  MSC_STAGE_STATUS,
};

// UnoR4-tinyusb deviation: upper bound for the LUN Test-Unit-Ready/Request-Sense
// loop during config. A media-less LUN (e.g. an empty card-reader slot) fails
// TUR forever, so the mount must proceed past it to the remaining LUNs.
enum { MSC_SENSE_MAX_RETRIES = 5 };

typedef struct {
  uint8_t itf_num;
  uint8_t ep_in;
  uint8_t ep_out;
  uint8_t max_lun;

  volatile bool configured; // Receive SET_CONFIGURE
  volatile bool mounted;    // Enumeration is complete

  // UnoR4-tinyusb deviation: bounded retries and LUN cursor for the multi-LUN
  // probe. Upstream retries TUR unbounded and only ever probes LUN 0.
  uint8_t sense_retries;
  uint8_t config_lun;

  // SCSI command data
  uint8_t stage;
  void* buffer;
  uint32_t data_xferred;
  tuh_msc_complete_cb_t complete_cb;
  uintptr_t complete_arg;

  struct {
    uint32_t block_size;
    uint32_t block_count;
  } capacity[CFG_TUH_MSC_MAXLUN];
} msch_interface_t;

typedef struct {
  TUH_EPBUF_TYPE_DEF(msc_cbw_t, cbw);
  TUH_EPBUF_TYPE_DEF(msc_csw_t, csw);
} msch_epbuf_t;

static msch_interface_t _msch_itf[CFG_TUH_DEVICE_MAX];
CFG_TUH_MEM_SECTION static msch_epbuf_t _msch_epbuf[CFG_TUH_DEVICE_MAX];

TU_ATTR_ALWAYS_INLINE static inline msch_interface_t* get_itf(uint8_t daddr) {
  return &_msch_itf[daddr - 1];
}

TU_ATTR_ALWAYS_INLINE static inline msch_epbuf_t* get_epbuf(uint8_t daddr) {
  return &_msch_epbuf[daddr - 1];
}

// usbh_edpt_xfer() length is 16-bit: a larger data stage is split into transfers of this size,
// a multiple of every bulk max packet size so that only the last one can end short
#define MSCH_DATA_XFER_MAX 0xFC00u

static bool data_stage_xfer(uint8_t daddr, msch_interface_t* p_msc, const msc_cbw_t* cbw) {
  const uint8_t  ep_data = (cbw->dir & TUSB_DIR_IN_MASK) ? p_msc->ep_in : p_msc->ep_out;
  const uint16_t len     = (uint16_t) tu_min32(cbw->total_bytes - p_msc->data_xferred, MSCH_DATA_XFER_MAX);
  return usbh_edpt_xfer(daddr, ep_data, (uint8_t*) p_msc->buffer + p_msc->data_xferred, len);
}

static bool status_stage_xfer(uint8_t daddr, msch_interface_t* p_msc, msc_csw_t* csw) {
  p_msc->stage = MSC_STAGE_STATUS;
  return usbh_edpt_xfer(daddr, p_msc->ep_in, (uint8_t*) csw, (uint16_t) sizeof(msc_csw_t));
}

//--------------------------------------------------------------------+
// Weak stubs: invoked if no strong implementation is available
//--------------------------------------------------------------------+
TU_ATTR_WEAK void tuh_msc_mount_cb(uint8_t dev_addr) {
  (void) dev_addr;
}

TU_ATTR_WEAK void tuh_msc_umount_cb(uint8_t dev_addr) {
  (void) dev_addr;
}

//--------------------------------------------------------------------+
// PUBLIC API
//--------------------------------------------------------------------+
uint8_t tuh_msc_get_maxlun(uint8_t dev_addr) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  return p_msc->max_lun;
}

uint32_t tuh_msc_get_block_count(uint8_t dev_addr, uint8_t lun) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  return p_msc->capacity[lun].block_count;
}

uint32_t tuh_msc_get_block_size(uint8_t dev_addr, uint8_t lun) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  return p_msc->capacity[lun].block_size;
}

bool tuh_msc_mounted(uint8_t dev_addr) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  return p_msc->mounted;
}

bool tuh_msc_ready(uint8_t dev_addr) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->mounted);
  const bool epin_busy = usbh_edpt_busy(dev_addr, p_msc->ep_in);
  const bool epout_busy = usbh_edpt_busy(dev_addr, p_msc->ep_out);
  return !epin_busy && !epout_busy;
}

//--------------------------------------------------------------------+
// PUBLIC API: SCSI COMMAND
//--------------------------------------------------------------------+
static inline void cbw_init(msc_cbw_t* cbw, uint8_t lun) {
  tu_memclr(cbw, sizeof(msc_cbw_t));
  cbw->signature = MSC_CBW_SIGNATURE;
  cbw->tag       = 0x54555342; // TUSB
  cbw->lun       = lun;
}

bool tuh_msc_scsi_command(uint8_t daddr, msc_cbw_t const* cbw, void* data,
                          tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(daddr);
  TU_VERIFY(p_msc->configured);

  // UnoR4-tinyusb deviation: reject overlapping commands. The stage machine
  // (CMD->DATA->STATUS->IDLE) tracks a single in-flight command; issuing a new
  // CBW mid-flight overwrites epbuf->cbw, buffer, callback and stage,
  // corrupting the pending command (observed on hardware: ep_out 0x01->0x12,
  // CBW routed to a ghost endpoint). Apps must serialize by chaining from
  // complete_cb; the examples also guard with a pending flag.
  TU_VERIFY(p_msc->stage == MSC_STAGE_IDLE, false);

  // claim endpoint
  TU_VERIFY(usbh_edpt_claim(daddr, p_msc->ep_out));
  msch_epbuf_t* epbuf = get_epbuf(daddr);

  epbuf->cbw = *cbw;
  p_msc->buffer = data;
  p_msc->complete_cb = complete_cb;
  p_msc->complete_arg = arg;
  p_msc->stage = MSC_STAGE_CMD;

  if (!usbh_edpt_xfer(daddr, p_msc->ep_out, (uint8_t*) &epbuf->cbw, sizeof(msc_cbw_t))) {
    (void) usbh_edpt_release(daddr, p_msc->ep_out);
    return false;
  }

  return true;
}

bool tuh_msc_read_capacity(uint8_t dev_addr, uint8_t lun, scsi_read_capacity10_resp_t* response,
                           tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->configured);

  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  cbw.total_bytes = sizeof(scsi_read_capacity10_resp_t);
  cbw.dir        = TUSB_DIR_IN_MASK;
  cbw.cmd_len    = sizeof(scsi_read_capacity10_t);
  cbw.command[0] = SCSI_CMD_READ_CAPACITY_10;

  return tuh_msc_scsi_command(dev_addr, &cbw, response, complete_cb, arg);
}

bool tuh_msc_inquiry(uint8_t dev_addr, uint8_t lun, scsi_inquiry_resp_t* response,
                     tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->mounted);

  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  cbw.total_bytes = sizeof(scsi_inquiry_resp_t);
  cbw.dir         = TUSB_DIR_IN_MASK;
  cbw.cmd_len     = sizeof(scsi_inquiry_t);

  scsi_inquiry_t const cmd_inquiry = {
      .cmd_code     = SCSI_CMD_INQUIRY,
      .alloc_length = sizeof(scsi_inquiry_resp_t)
  };
  memcpy(cbw.command, &cmd_inquiry, cbw.cmd_len); //-V1086

  return tuh_msc_scsi_command(dev_addr, &cbw, response, complete_cb, arg);
}

bool tuh_msc_test_unit_ready(uint8_t dev_addr, uint8_t lun, tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->configured);

  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  cbw.total_bytes = 0;
  cbw.dir        = TUSB_DIR_OUT;
  cbw.cmd_len    = sizeof(scsi_test_unit_ready_t);
  cbw.command[0] = SCSI_CMD_TEST_UNIT_READY;
  cbw.command[1] = lun; // according to wiki TODO need verification

  return tuh_msc_scsi_command(dev_addr, &cbw, NULL, complete_cb, arg);
}

bool tuh_msc_request_sense(uint8_t dev_addr, uint8_t lun, void* response,
                           tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  cbw.total_bytes = 18; // TODO sense response
  cbw.dir         = TUSB_DIR_IN_MASK;
  cbw.cmd_len     = sizeof(scsi_request_sense_t);

  scsi_request_sense_t const cmd_request_sense = {
      .cmd_code     = SCSI_CMD_REQUEST_SENSE,
      .alloc_length = 18
  };
  memcpy(cbw.command, &cmd_request_sense, cbw.cmd_len); //-V1086

  return tuh_msc_scsi_command(dev_addr, &cbw, response, complete_cb, arg);
}

bool tuh_msc_read10(uint8_t dev_addr, uint8_t lun, void* buffer, uint32_t lba, uint16_t block_count,
                    tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->mounted);

  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  const uint32_t block_size = p_msc->capacity[lun].block_size;
  TU_VERIFY(block_count <= UINT32_MAX / tu_max32(block_size, 1)); // CBW data length is 32-bit
  cbw.total_bytes = block_count * block_size;
  cbw.dir = TUSB_DIR_IN_MASK;
  cbw.cmd_len = sizeof(scsi_read10_t);

  scsi_read10_t const cmd_read10 = {
      .cmd_code    = SCSI_CMD_READ_10,
      .lba         = tu_htonl(lba),
      .block_count = tu_htons(block_count)
  };
  memcpy(cbw.command, &cmd_read10, cbw.cmd_len); //-V1086

  return tuh_msc_scsi_command(dev_addr, &cbw, buffer, complete_cb, arg);
}

bool tuh_msc_write10(uint8_t dev_addr, uint8_t lun, void const* buffer, uint32_t lba, uint16_t block_count,
                     tuh_msc_complete_cb_t complete_cb, uintptr_t arg) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->mounted);

  msc_cbw_t cbw;
  cbw_init(&cbw, lun);

  const uint32_t block_size = p_msc->capacity[lun].block_size;
  TU_VERIFY(block_count <= UINT32_MAX / tu_max32(block_size, 1)); // CBW data length is 32-bit
  cbw.total_bytes = block_count * block_size;
  cbw.dir         = TUSB_DIR_OUT;
  cbw.cmd_len     = sizeof(scsi_write10_t);

  scsi_write10_t const cmd_write10 = {
      .cmd_code    = SCSI_CMD_WRITE_10,
      .lba         = tu_htonl(lba),
      .block_count = tu_htons(block_count)
  };
  memcpy(cbw.command, &cmd_write10, cbw.cmd_len); //-V1086

  return tuh_msc_scsi_command(dev_addr, &cbw, (void*) (uintptr_t) buffer, complete_cb, arg);
}

#if 0
// MSC interface Reset (not used now)
bool tuh_msc_reset(uint8_t dev_addr) {
  tusb_control_request_t const new_request = {
    .bmRequestType_bit = {
      .recipient = TUSB_REQ_RCPT_INTERFACE,
      .type      = TUSB_REQ_TYPE_CLASS,
      .direction = TUSB_DIR_OUT
    },
    .bRequest = MSC_REQ_RESET,
    .wValue   = 0,
    .wIndex   = p_msc->itf_num,
    .wLength  = 0
  };
  TU_ASSERT( usbh_control_xfer( dev_addr, &new_request, NULL ) );
}
#endif

//--------------------------------------------------------------------+
// CLASS-USBH API
//--------------------------------------------------------------------+
bool msch_init(void) {
  TU_LOG_DRV("sizeof(msch_interface_t) = %u\r\n", sizeof(msch_interface_t));
  TU_LOG_DRV("sizeof(msch_epbuf_t) = %u\r\n", sizeof(msch_epbuf_t));
  tu_memclr(_msch_itf, sizeof(_msch_itf));
  return true;
}

bool msch_deinit(void) {
  return true;
}

void msch_close(uint8_t dev_addr) {
  TU_VERIFY(dev_addr <= CFG_TUH_DEVICE_MAX,);
  msch_interface_t* p_msc = get_itf(dev_addr);
  TU_VERIFY(p_msc->configured,);

  TU_LOG_DRV("  MSCh close addr = %d\r\n", dev_addr);

  // invoke Application Callback
  if (p_msc->mounted) {
    tuh_msc_umount_cb(dev_addr);
  }

  tu_memclr(p_msc, sizeof(msch_interface_t));
}

bool msch_xfer_cb(uint8_t dev_addr, uint8_t ep_addr, xfer_result_t event, uint32_t xferred_bytes) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  msch_epbuf_t* epbuf = get_epbuf(dev_addr);
  msc_cbw_t const * cbw = &epbuf->cbw;
  msc_csw_t       * csw = &epbuf->csw;

  switch (p_msc->stage) {
    case MSC_STAGE_CMD:
      // Must be Command Block
      TU_ASSERT(ep_addr == p_msc->ep_out && event == XFER_RESULT_SUCCESS && xferred_bytes == sizeof(msc_cbw_t));
      if (cbw->total_bytes && p_msc->buffer) {
        // Data stage if any
        p_msc->stage = MSC_STAGE_DATA;
        p_msc->data_xferred = 0;
        TU_ASSERT(data_stage_xfer(dev_addr, p_msc, cbw));
      } else {
        TU_ASSERT(status_stage_xfer(dev_addr, p_msc, csw));
      }
      break;

    case MSC_STAGE_DATA:
      p_msc->data_xferred += xferred_bytes;
      if (event == XFER_RESULT_SUCCESS && xferred_bytes == MSCH_DATA_XFER_MAX &&
          p_msc->data_xferred < cbw->total_bytes) {
        TU_ASSERT(data_stage_xfer(dev_addr, p_msc, cbw));
      } else {
        TU_ASSERT(status_stage_xfer(dev_addr, p_msc, csw));
      }
      break;

    case MSC_STAGE_STATUS:
      // SCSI op is complete
      p_msc->stage = MSC_STAGE_IDLE;
      // UnoR4-tinyusb deviation: cache per-LUN geometry for app-initiated
      // reads too. Media can become ready after the config-time probe left
      // capacity[lun] at 0, so a later READ_CAPACITY must refresh it.
      if (csw->status == 0 && cbw->command[0] == SCSI_CMD_READ_CAPACITY_10 &&
          cbw->lun < CFG_TUH_MSC_MAXLUN && p_msc->buffer != NULL) {
        scsi_read_capacity10_resp_t const* resp =
          (scsi_read_capacity10_resp_t const*) (uintptr_t) p_msc->buffer;
        p_msc->capacity[cbw->lun].block_count = (uint32_t) (tu_ntohl(resp->last_lba) + 1u);
        p_msc->capacity[cbw->lun].block_size  = tu_ntohl(resp->block_size);
      }
      if (p_msc->complete_cb != NULL) {
        tuh_msc_complete_data_t const cb_data = {
            .cbw = cbw,
            .csw = csw,
            .scsi_data = p_msc->buffer,
            .user_arg = p_msc->complete_arg
        };
        (void) p_msc->complete_cb(dev_addr, &cb_data);
      }
      break;

    default:
      // unknown state
      break;
  }

  return true;
}

//--------------------------------------------------------------------+
// MSC Enumeration
//--------------------------------------------------------------------+
static void config_get_maxlun_complete(tuh_xfer_t* xfer);
static bool config_test_unit_ready_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data);
static bool config_request_sense_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data);
static bool config_read_capacity_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data);

uint16_t msch_open(uint8_t rhport, uint8_t dev_addr, const tusb_desc_interface_t *desc_itf, uint16_t max_len) {
  (void) rhport;
  TU_VERIFY(MSC_SUBCLASS_SCSI == desc_itf->bInterfaceSubClass && MSC_PROTOCOL_BOT == desc_itf->bInterfaceProtocol, 0);

  // msc driver length is fixed
  const uint16_t drv_len =
    (uint16_t)(sizeof(tusb_desc_interface_t) + desc_itf->bNumEndpoints * sizeof(tusb_desc_endpoint_t));
  TU_ASSERT(drv_len <= max_len, 0);

  msch_interface_t           *p_msc   = get_itf(dev_addr);
  const tusb_desc_endpoint_t *ep_desc = (const tusb_desc_endpoint_t *)tu_desc_next(desc_itf);

  for (uint32_t i = 0; i < 2; i++) {
    TU_ASSERT(TUSB_DESC_ENDPOINT == ep_desc->bDescriptorType && TUSB_XFER_BULK == ep_desc->bmAttributes.xfer, 0);
    TU_ASSERT(tuh_edpt_open(dev_addr, ep_desc), 0);

    if (TUSB_DIR_IN == tu_edpt_dir(ep_desc->bEndpointAddress)) {
      p_msc->ep_in = ep_desc->bEndpointAddress;
    } else {
      p_msc->ep_out = ep_desc->bEndpointAddress;
    }

    ep_desc = (tusb_desc_endpoint_t const*) tu_desc_next(ep_desc);
  }

  p_msc->itf_num = desc_itf->bInterfaceNumber;

  return drv_len;
}

bool msch_set_config(uint8_t daddr, uint8_t itf_num) {
  msch_interface_t* p_msc = get_itf(daddr);
  TU_ASSERT(p_msc->itf_num == itf_num);
  p_msc->configured = true;

  //------------- Get Max Lun -------------//
  TU_LOG_DRV("MSC Get Max Lun\r\n");
  tusb_control_request_t const request = {
      .bmRequestType_bit = {
          .recipient = TUSB_REQ_RCPT_INTERFACE,
          .type      = TUSB_REQ_TYPE_CLASS,
          .direction = TUSB_DIR_IN
      },
      .bRequest = MSC_REQ_GET_MAX_LUN,
      .wValue   = 0,
      .wIndex   = itf_num,
      .wLength  = 1
  };

  uint8_t* enum_buf = usbh_get_enum_buf();
  tuh_xfer_t xfer = {
      .daddr       = daddr,
      .ep_addr     = 0,
      .setup       = &request,
      .buffer      = enum_buf,
      .complete_cb = config_get_maxlun_complete,
      .user_data    = 0
  };
  TU_ASSERT(tuh_control_xfer(&xfer));

  return true;
}

static void config_get_maxlun_complete(tuh_xfer_t* xfer) {
  uint8_t const daddr = xfer->daddr;
  msch_interface_t* p_msc = get_itf(daddr);

  // MAXLUN's response is minus 1 by specs, STALL means 1
  if (XFER_RESULT_SUCCESS == xfer->result) {
    uint8_t* enum_buf = usbh_get_enum_buf();
    p_msc->max_lun = enum_buf[0] + 1;
  } else {
    p_msc->max_lun = 1;
  }

  // UnoR4-tinyusb deviation: clamp max_lun to the compiled capacity array so a
  // device advertising more LUNs than CFG_TUH_MSC_MAXLUN cannot index past it.
  if (p_msc->max_lun > CFG_TUH_MSC_MAXLUN) {
    p_msc->max_lun = CFG_TUH_MSC_MAXLUN;
  }
  p_msc->sense_retries = 0;
  p_msc->config_lun = 0;

  TU_LOG_DRV("  Max LUN = %u\r\n", p_msc->max_lun);

  // UnoR4-tinyusb deviation: walk every LUN (upstream probes only LUN 0).
  TU_LOG_DRV("SCSI Test Unit Ready LUN%u\r\n", p_msc->config_lun);
  tuh_msc_test_unit_ready(daddr, p_msc->config_lun, config_test_unit_ready_complete, 0);
}

static bool config_test_unit_ready_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data) {
  msc_cbw_t const* cbw = cb_data->cbw;
  msc_csw_t const* csw = cb_data->csw;
  uint8_t* enum_buf = usbh_get_enum_buf();

  if (csw->status == 0) {
    // Unit is ready, read its capacity
    TU_LOG_DRV("SCSI Read Capacity\r\n");
    tuh_msc_read_capacity(dev_addr, cbw->lun, (scsi_read_capacity10_resp_t*) (uintptr_t) enum_buf,
                          config_read_capacity_complete, 0);
  } else {
    // Note: During enumeration, some device fails Test Unit Ready and require a few retries
    // with Request Sense to start working !!
    TU_LOG_DRV("SCSI Request Sense\r\n");
    TU_ASSERT(tuh_msc_request_sense(dev_addr, cbw->lun, enum_buf, config_request_sense_complete, 0));
  }

  return true;
}

// UnoR4-tinyusb deviation: advance the config walk to the next LUN, or finish.
// Mount fires once every LUN has been probed, even when none is ready, so
// hot-inserted media and an app-driven rescan still work.
static bool config_advance_lun(uint8_t dev_addr) {
  msch_interface_t* p_msc = get_itf(dev_addr);
  if (p_msc->config_lun + 1u < p_msc->max_lun) {
    p_msc->config_lun++;
    p_msc->sense_retries = 0;
    TU_LOG_DRV("SCSI Test Unit Ready LUN%u\r\n", p_msc->config_lun);
    TU_ASSERT(tuh_msc_test_unit_ready(dev_addr, p_msc->config_lun, config_test_unit_ready_complete, 0));
    return true;
  }
  p_msc->mounted = true;
  tuh_msc_mount_cb(dev_addr);
  usbh_driver_set_config_complete(dev_addr, p_msc->itf_num);
  return true;
}

static bool config_request_sense_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data) {
  msc_cbw_t const* cbw = cb_data->cbw;
  msc_csw_t const* csw = cb_data->csw;
  msch_interface_t* p_msc = get_itf(dev_addr);

  TU_ASSERT(csw->status == 0);
  // UnoR4-tinyusb deviation: bounded retries. Upstream's "TODO limit number of
  // retries" left this unbounded, so a media-less LUN hangs the mount forever.
  if (p_msc->sense_retries >= MSC_SENSE_MAX_RETRIES) {
    TU_LOG_DRV("  LUN%u not ready after %u retries, skipping\r\n", cbw->lun, p_msc->sense_retries);
    return config_advance_lun(dev_addr);
  }
  p_msc->sense_retries++;
  TU_ASSERT(tuh_msc_test_unit_ready(dev_addr, cbw->lun, config_test_unit_ready_complete, 0));
  return true;
}

static bool config_read_capacity_complete(uint8_t dev_addr, tuh_msc_complete_data_t const* cb_data) {
  msc_cbw_t const* cbw = cb_data->cbw;
  msc_csw_t const* csw = cb_data->csw;
  TU_ASSERT(csw->status == 0);
  msch_interface_t* p_msc = get_itf(dev_addr);
  uint8_t* enum_buf = usbh_get_enum_buf();

  // Capacity response field: Block size and Last LBA are both Big-Endian
  scsi_read_capacity10_resp_t* resp = (scsi_read_capacity10_resp_t*) (uintptr_t) enum_buf;
  p_msc->capacity[cbw->lun].block_count = (uint32_t) (tu_ntohl(resp->last_lba) + 1u);
  p_msc->capacity[cbw->lun].block_size  = tu_ntohl(resp->block_size);

  // UnoR4-tinyusb deviation: this LUN is ready, move on to the next one.
  // Mount fires from config_advance_lun once all LUNs have been probed.
  return config_advance_lun(dev_addr);
}

#endif
